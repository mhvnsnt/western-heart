quickbms -G -w -r
